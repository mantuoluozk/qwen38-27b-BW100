"""Small local completion client, executed inside the serving container."""
import json
import os
import urllib.request

model = os.environ["DEMO_MODEL"]
payload = {"model": model, "prompt": "Question: What is 1 + 1?\nAnswer:",
           "max_tokens": 64, "temperature": 0, "stream": False}
request = urllib.request.Request("http://127.0.0.1:18580/v1/completions",
                                 data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open(request, timeout=180) as response:
    result = json.load(response)
print(json.dumps(result, ensure_ascii=False, indent=2))
if not result.get("choices") or not result["choices"][0].get("text"):
    raise SystemExit("No completion text returned")
