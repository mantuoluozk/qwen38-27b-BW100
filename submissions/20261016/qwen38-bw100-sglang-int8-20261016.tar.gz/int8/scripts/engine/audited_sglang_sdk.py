"""OpenCompass API adapter with passive response auditing; generation is unchanged."""
import hashlib
import json
import os
import threading
import time
from pathlib import Path

from opencompass.models import OpenAISDK
from opencompass.registry import MODELS


@MODELS.register_module()
class AuditedSGLangSDK(OpenAISDK):
    def __init__(self, audit_path=None, **kwargs):
        base = kwargs.get('openai_api_base', '')
        if base != 'http://127.0.0.1:18580/v1/':
            raise ValueError('This adapter is restricted to our local SGLang endpoint')
        audit_path = audit_path or os.environ.get('QWEN_EVAL_AUDIT')
        if not audit_path:
            raise ValueError('QWEN_EVAL_AUDIT or audit_path is required')
        self.audit_path = Path(audit_path).resolve()
        if not self.audit_path.is_relative_to(Path('/data/zk/qwen38')):
            raise ValueError('Audit path must stay inside the task workspace')
        self.audit_path.parent.mkdir(parents=True, exist_ok=True)
        self.audit_lock = threading.Lock()
        options = dict(kwargs.pop('http_client_cfg', {}) or {})
        hooks = {key: list(value) for key, value in options.pop('event_hooks', {}).items()}
        hooks.setdefault('response', []).append(self._audit_response)
        options['event_hooks'] = hooks
        options['trust_env'] = False
        super().__init__(http_client_cfg=options, **kwargs)

    def _audit_response(self, response):
        # Non-streaming chat API: reading here does not consume the cached body.
        response.read()
        try:
            body = response.json()
        except ValueError:
            body = {}
        try:
            request = json.loads(response.request.content)
        except (ValueError, TypeError):
            request = {}
        choices = body.get('choices') or []
        choice = choices[0] if choices else {}
        message = choice.get('message') or {}
        content = message.get('content') or ''
        reasoning = message.get('reasoning_content') or message.get('reasoning') or ''
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False)
        if not isinstance(reasoning, str):
            reasoning = json.dumps(reasoning, ensure_ascii=False)
        record = {
            'recorded_at': time.time(), 'status_code': response.status_code,
            'response_id': body.get('id'), 'model': body.get('model'),
            'request_sha256': hashlib.sha256(json.dumps(request, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
            'messages_sha256': hashlib.sha256(json.dumps(request.get('messages'), sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
            'requested_max_tokens': request.get('max_tokens'),
            'temperature': request.get('temperature'), 'seed': request.get('seed'),
            'finish_reason': choice.get('finish_reason'), 'usage': body.get('usage'),
            'content_chars': len(content), 'reasoning_chars': len(reasoning),
            'content_sha256': hashlib.sha256(content.encode()).hexdigest(),
            'reasoning_sha256': hashlib.sha256(reasoning.encode()).hexdigest(),
            'response_parseable': bool(body),
        }
        with self.audit_lock, self.audit_path.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + '\n')

