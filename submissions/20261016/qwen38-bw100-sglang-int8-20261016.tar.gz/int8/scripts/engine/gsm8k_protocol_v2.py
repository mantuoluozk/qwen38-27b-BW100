"""Declared, reference-independent answer formatting for future live GSM8K runs."""
import re

from opencompass.registry import TEXT_POSTPROCESSORS
from opencompass.utils.text_postprocessors import extract_non_reasoning_content


@TEXT_POSTPROCESSORS.register_module('qwen38-gsm8k-format-v2')
def normalize_gsm8k_v2(text):
    final = extract_non_reasoning_content(text)
    return re.sub(r'(?<=\d),(?=\d{3}(?:\D|$))', '', final)
