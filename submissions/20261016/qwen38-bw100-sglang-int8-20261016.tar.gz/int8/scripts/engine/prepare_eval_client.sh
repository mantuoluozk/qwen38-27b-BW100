#!/usr/bin/env bash
# Run inside zk-qwen38. Adds only a task-local CPU client environment.
set -euo pipefail
workdir=/data/zk/qwen38
client="$workdir/eval/client-20261012b"
[[ ! -e "$client" ]] || { echo 'Client directory already exists; refusing overwrite'; exit 2; }
mkdir -p "$client"
export HIP_VISIBLE_DEVICES=''
export ROCR_VISIBLE_DEVICES=''
export CUDA_VISIBLE_DEVICES=''
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
python3 -m pip --isolated list --format=json > "$client/base-packages-before.json"
python3 -m venv --without-pip --system-site-packages "$client/venv"
# Ubuntu image lacks ensurepip. Bootstrap only this venv via pip's --python switch.
python3 -m pip --isolated --python "$client/venv/bin/python" install \
  --ignore-installed --no-deps --timeout 30 --retries 1 \
  --index-url https://pypi.tuna.tsinghua.edu.cn/simple \
  pip==25.2 setuptools==80.9.0 wheel==0.45.1 > "$client/bootstrap.log" 2>&1
mkdir "$client/source"
tar -xf "$workdir/datasets/opencompass-93a0bcb-source.tar" -C "$client/source"
sha256sum "$workdir/datasets/opencompass-93a0bcb-source.tar" "$workdir/scripts/eval-client-requirements.txt" \
  > "$client/source-checksums.txt"
"$client/venv/bin/python" -m pip --isolated install --no-deps --timeout 30 --retries 1 \
  --index-url https://pypi.tuna.tsinghua.edu.cn/simple \
  -r "$workdir/scripts/eval-client-requirements.txt" > "$client/install.log" 2>&1
"$client/venv/bin/python" -m pip --isolated freeze --all > "$client/effective-packages.txt"
python3 -m pip --isolated list --format=json > "$client/base-packages-after.json"
cmp "$client/base-packages-before.json" "$client/base-packages-after.json"
echo 'Task-local client additions installed; base package list unchanged. Import/config validation still required.'
