#!/usr/bin/env bash
# Full 1319-example local GSM8K audit; inference remains on the selected DCUs.
set -euo pipefail
workdir=/data/zk/qwen38
exp_id=${1:?experiment ID required}
precision=${2:?precision must be bf16 or int8}
: "${DCU_DEVICES:?set the two physical DCU IDs after checking occupancy}"
client="$workdir/eval/client-20261012b"
run_dir="$workdir/runs/$exp_id"
[[ ! -e "$run_dir" ]] || { echo "Experiment already exists: $exp_id" >&2; exit 2; }
case "$precision" in
  bf16)
    container=zk-qwen38
    model_path="$workdir/model"
    served_model_name=qwen38-bf16
    variant=fa3_hcu_contigfa_eagle314_slots32_no_custom_ar
    config="$workdir/scripts/gsm8k_eval_final_bf16.py"
    ;;
  int8)
    container=zk-qwen38-int8
    model_path=/data1/model/Qwen3.8-27B-Channel-INT8-w8a8
    served_model_name=qwen38-int8
    variant=fa3_hcu_contigfa_eagle314_slots64_no_custom_ar
    config="$workdir/scripts/gsm8k_eval_final_int8.py"
    ;;
  *) echo 'precision must be bf16 or int8' >&2; exit 2 ;;
esac
[[ -x "$client/venv/bin/python" && -r "$config" ]] || { echo 'Evaluation client/config missing' >&2; exit 2; }
printf '%s  %s\n' \
  17f347dc51477c50d4efb83959dbb7c56297aba886e5544ee2aaed3024813465 "$workdir/datasets/gsm8k/train.jsonl" \
  3730d312f6e3440559ace48831e51066acaca737f6eabec99bccb9e4b3c39d14 "$workdir/datasets/gsm8k/test.jsonl" \
  | sha256sum -c -
started=false
cleanup() {
  status=$?
  if [[ "$started" == true ]]; then
    CONTAINER="$container" "$workdir/scripts/stop_server.sh" "$exp_id" || status=1
    printf 'eval_end=%s\nrunner_status=%s\n' "$(date -Is)" "$status" >> "$run_dir/eval-runner.txt"
  fi
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
DCU_DEVICES="$DCU_DEVICES" CONTAINER="$container" MODEL_PATH="$model_path" SERVED_MODEL_NAME="$served_model_name" \
  "$workdir/scripts/start_baseline.sh" "$exp_id" "$variant"
started=true
printf 'eval_start=%s\nkind=full-GSM8K-1319-local-v3\nprecision=%s\nmeasure_rounds=1\nclient_concurrency=4\nmax_out_tokens=16384\ncontainer=%s\nselected_devices=%s\n' \
  "$(date -Is)" "$precision" "$container" "$DCU_DEVICES" > "$run_dir/eval-runner.txt"
sha256sum "$config" "$workdir/scripts/gsm8k_eval_v2.py" "$workdir/scripts/gsm8k_eval_4shot.py" \
  "$workdir/scripts/gsm8k_protocol_v2.py" \
  "$workdir/scripts/audited_sglang_sdk.py" "$workdir/scripts/summarize_gsm8k_screen.py" \
  >> "$run_dir/eval-runner.txt"
ready=false
for attempt in $(seq 1 180); do
  if docker exec "$container" curl -sf --max-time 3 http://127.0.0.1:18580/health >/dev/null; then
    ready=true
    break
  fi
  if grep -qE 'Traceback|OutOfMemoryError|RuntimeError:' "$run_dir/server.log"; then
    tail -n 25 "$run_dir/server.log"
    exit 1
  fi
  sleep 2
done
[[ "$ready" == true ]] || { echo 'Server readiness timeout' >&2; exit 1; }
docker exec -e HIP_VISIBLE_DEVICES= -e ROCR_VISIBLE_DEVICES= -e CUDA_VISIBLE_DEVICES= \
  -e OMP_NUM_THREADS=2 -e MKL_NUM_THREADS=2 \
  -e PYTHONPATH="$client/source:$workdir/scripts" \
  -e QWEN_EVAL_AUDIT="$run_dir/responses-audit.jsonl" \
  "$container" timeout --signal=TERM --kill-after=30s 14400s \
  "$client/venv/bin/python" "$workdir/scripts/run_eval_cpu.py" "$client/source/run.py" \
  "$config" --debug -w "$run_dir/accuracy-full-v3" \
  > "$run_dir/accuracy-full-v3.log" 2>&1
docker exec "$container" python3 "$workdir/scripts/summarize_gsm8k_screen.py" \
  "$run_dir" --artifact-subdir accuracy-full-v3 --dataset-abbr gsm8k-full-final-16384 \
  --expected 1319 --requested-max-tokens 16384 \
  --output "$run_dir/accuracy-full-v3-audit-summary.json" \
  > "$run_dir/accuracy-full-v3-audit.log" 2>&1
docker exec "$container" curl -sf --max-time 10 http://127.0.0.1:18580/metrics \
  > "$run_dir/end-metrics.prom" || true
