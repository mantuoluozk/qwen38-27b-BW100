"""Prospectively fixed full-test protocol; not yet an official admission claim."""
from mmengine.config import read_base

with read_base():
    from .gsm8k_eval_4shot import datasets, models

from audited_sglang_sdk import AuditedSGLangSDK
from gsm8k_protocol_v2 import normalize_gsm8k_v2

datasets[0]['abbr'] = 'gsm8k-full-fixed-protocol-v2'
models[0]['type'] = AuditedSGLangSDK
models[0]['abbr'] = 'qwen38-bf16-audited-v2'
models[0]['batch_size'] = 4
models[0]['max_workers'] = 4
models[0]['query_per_second'] = 4
models[0]['pred_postprocessor'] = dict(type=normalize_gsm8k_v2)

# No subset selection. Dataset extractor, references and evaluator are unchanged.
# Generation cap8192, temperature0, seed0 and all four prompt exemplars inherited.
# Any future launch must set QWEN_EVAL_AUDIT and validate every response.
