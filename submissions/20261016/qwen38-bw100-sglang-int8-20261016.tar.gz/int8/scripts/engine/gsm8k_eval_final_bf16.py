"""Full GSM8K local protocol v3 for the final BF16 slots32 candidate."""
from mmengine.config import read_base

with read_base():
    from .gsm8k_eval_v2 import datasets, models

datasets[0]['abbr'] = 'gsm8k-full-final-16384'
datasets[0]['infer_cfg']['inferencer']['max_out_len'] = 16384
models[0]['abbr'] = 'qwen38-bf16-final-accuracy'
models[0]['path'] = 'qwen38-bf16'
models[0]['tokenizer_path'] = '/data/zk/qwen38/model'
models[0]['max_out_len'] = 16384
