"""Provisional full GSM8K protocol, not an organizer-approved accuracy claim.

Run through pinned OpenCompass with this directory and its source on PYTHONPATH.
Do not run inference unless the selected two DCUs are available and our own service is started.
"""
import copy

from mmengine.config import read_base

with read_base():
    from opencompass.configs.datasets.gsm8k.gsm8k_gen_1d7fe4 import gsm8k_datasets

from opencompass.models import OpenAISDK

datasets = copy.deepcopy(gsm8k_datasets)
for dataset in datasets:
    dataset['path'] = '/data/zk/qwen38/datasets/gsm8k'
    dataset['infer_cfg']['inferencer']['max_out_len'] = 8192

models = [dict(
    type=OpenAISDK,
    abbr='qwen38-bf16-api-4shot-cot',
    path='qwen38-bf16',
    key='EMPTY',  # Local self-hosted endpoint placeholder, not a provider credential.
    openai_api_base='http://127.0.0.1:18580/v1/',
    tokenizer_path='/data/zk/qwen38/model',
    max_seq_len=131072,
    max_out_len=8192,
    batch_size=1,
    max_workers=1,
    query_per_second=1,
    retry=2,
    temperature=0.0,
    timeout=300,
    http_client_cfg=dict(trust_env=False),
    extra_body=dict(seed=0),
    run_cfg=dict(num_gpus=0),
)]
del copy
del dataset
del gsm8k_datasets

# No thinking toggle or custom answer extraction: use pinned defaults uniformly.
# The response-length cap differs from stock 512 and must be declared for A/B.
# A future live run must also audit finish_reason/usage; truncated reasoning
# must never be presented as a completed full-answer evaluation.
