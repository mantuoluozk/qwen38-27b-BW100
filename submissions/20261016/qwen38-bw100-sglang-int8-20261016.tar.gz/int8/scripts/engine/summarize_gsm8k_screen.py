"""Validate fixed64 OpenCompass screening and passive API audit, without altering scores."""
import argparse
import collections
import hashlib
import json
from pathlib import Path


def summarize(run_dir, artifact_subdir='accuracy-first64', dataset_abbr='gsm8k-fixed-first64-not-admission', expected=64, requested_max_tokens=8192):
    root = run_dir / artifact_subdir
    result_paths = list(root.glob(f'*/results/*/{dataset_abbr}.json'))
    prediction_paths = list(root.glob(f'*/predictions/*/{dataset_abbr}.json'))
    if len(result_paths) != 1 or len(prediction_paths) != 1:
        raise ValueError('Expected one completed result/prediction artifact')
    result = json.loads(result_paths[0].read_text(encoding='utf-8'))
    predictions = json.loads(prediction_paths[0].read_text(encoding='utf-8'))
    audits = [json.loads(line) for line in (run_dir / 'responses-audit.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    details = result.get('details', [])
    problems = []
    if len(predictions) != expected or len(details) != expected:
        problems.append('Incomplete predictions/evaluation details')
    if len(audits) != expected:
        problems.append(f'Audit request count differs from {expected}; inspect retries/failures')
    if len({row['messages_sha256'] for row in audits}) != expected:
        problems.append('Messages are missing or repeated in audit')
    for row in audits:
        if row['status_code'] != 200 or not row['response_parseable']:
            problems.append('HTTP or malformed response')
        if row['requested_max_tokens'] != requested_max_tokens or row['temperature'] != 0.0 or row['seed'] != 0:
            problems.append('Unexpected sampling parameters')
        if row['finish_reason'] != 'stop':
            problems.append('Non-stop finish reason')
        if not row['content_chars']:
            problems.append('Missing final content')
        usage = row.get('usage') or {}
        if not all(isinstance(usage.get(key), int) and usage[key] > 0
                   for key in ['prompt_tokens', 'completion_tokens', 'total_tokens']):
            problems.append('Missing/invalid usage')
        elif usage['prompt_tokens'] + usage['completion_tokens'] != usage['total_tokens']:
            problems.append('Usage token sum mismatch')
        elif usage['completion_tokens'] > row['requested_max_tokens']:
            problems.append('Completion usage exceeds requested cap')
    correct = 0
    wrong = []
    for detail in details:
        values = detail['correct']
        if isinstance(values, list):
            if len(values) != 1:
                problems.append('Unexpected multi-generation score')
            values = values[0]
        if values:
            correct += 1
        else:
            wrong.append({'example': detail['example_abbr'], 'prediction': detail['pred'], 'reference': detail['answer']})
    ordered_hashes = sorted(row['messages_sha256'] for row in audits)
    summary = {
        'run_dir': str(run_dir), 'protocol_valid': not problems,
        'problems': sorted(set(problems)),
        'kind': 'FIXED_FIRST64_SCREENING_NOT_ADMISSION' if expected == 64 else 'FULL_TEST_LOCAL_PROTOCOL_NOT_OFFICIAL_ADMISSION',
        'accuracy_admission_verified': False, 'accuracy_percent': result['accuracy'],
        'correct': correct, 'evaluated': len(details), 'audit_responses': len(audits),
        'finish_reasons': dict(collections.Counter(row['finish_reason'] for row in audits)),
        'empty_content_count': sum(row['content_chars'] == 0 for row in audits),
        'cap_hit_count': sum((row.get('usage') or {}).get('completion_tokens', 0) >= row['requested_max_tokens'] for row in audits),
        'max_prompt_tokens': max((row.get('usage') or {}).get('prompt_tokens', 0) for row in audits),
        'max_completion_tokens': max((row.get('usage') or {}).get('completion_tokens', 0) for row in audits),
        'total_prompt_tokens': sum((row.get('usage') or {}).get('prompt_tokens', 0) for row in audits),
        'total_completion_tokens': sum((row.get('usage') or {}).get('completion_tokens', 0) for row in audits),
        'messages_multiset_sha256': hashlib.sha256(json.dumps(ordered_hashes).encode()).hexdigest(),
        'wrong_examples': wrong,
    }
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('run_dir', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--artifact-subdir', default='accuracy-first64')
    parser.add_argument('--dataset-abbr', default='gsm8k-fixed-first64-not-admission')
    parser.add_argument('--expected', type=int, default=64)
    parser.add_argument('--requested-max-tokens', type=int, default=8192)
    args = parser.parse_args()
    summary = summarize(args.run_dir, args.artifact_subdir, args.dataset_abbr, args.expected, args.requested_max_tokens)
    if args.output:
        if args.output.exists():
            raise FileExistsError('Refusing to overwrite summary')
        args.output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    raise SystemExit(0 if summary['protocol_valid'] else 1)
