"""Launch pinned OpenCompass CPU/API tasks without importing local GPU backends.

The base image has an optional vLLM HCU plugin that probes DCUs at import.
Expose those optional backends as unavailable to this client only. Never use
this launcher for local vLLM/lmdeploy/sglang model inference.
"""
import importlib.abc
import os
import runpy
import sys


class APIOnlyImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'vllm', 'vllm_hcu', 'lmdeploy', 'sglang'}:
            raise ModuleNotFoundError('GPU backend disabled in CPU/API client: ' + fullname)
        return None


for name in ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES'):
    os.environ[name] = ''
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('MKL_NUM_THREADS', '2')
sys.meta_path.insert(0, APIOnlyImports())
if len(sys.argv) < 2:
    raise SystemExit('Usage: run_eval_cpu.py TARGET.py [target arguments]')
target_script = sys.argv[1]
sys.argv = sys.argv[1:]
runpy.run_path(target_script, run_name='__main__')
