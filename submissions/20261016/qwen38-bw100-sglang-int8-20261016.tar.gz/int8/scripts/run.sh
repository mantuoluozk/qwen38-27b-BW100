#!/usr/bin/env bash
set -euo pipefail
package_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
source "$package_root/config/runtime.env"
export CONTAINER MODEL_PATH SERVED_MODEL_NAME
export SGLANG_NN_GEMM_7168=0
workdir=/data/zk/qwen38
action=${1:?Usage: run.sh start|stop|demo|fixed-4k|fixed-64k|peak-4k|peak-64k|sharegpt|accuracy [new-run-id]}
if [[ "$action" == demo ]]; then
  docker exec -i -e DEMO_MODEL="$SERVED_MODEL_NAME" "$CONTAINER" python3 - < "$package_root/scripts/demo_client.py"
  exit
fi
run_id=${2:?run ID required}
[[ "$run_id" =~ ^[A-Za-z0-9_-]+$ ]] || { echo 'Invalid run ID'; exit 2; }
if [[ "$action" == stop ]]; then
  [[ -r "$workdir/runs/$run_id/manifest.txt" ]] || exit 2
  grep -Fxq "served_model_name=$SERVED_MODEL_NAME" "$workdir/runs/$run_id/manifest.txt" || exit 2
  bash "$workdir/scripts/stop_server.sh" "$run_id"
  exit
fi
: "${DCU_DEVICES:?select two idle physical DCUs explicitly}"
export DCU_DEVICES
export FIXED_INPUT_LEN=4096 FIXED_SMOKE_64K=0 FIXED_MEASURE_ROUNDS=1 FIXED_WARMUP_ROUNDS=2
unset FIXED_REQUESTS_PER_ROUND
case "$action" in
  start)
    bash "$workdir/scripts/start_baseline.sh" "$run_id" "$VARIANT"
    for attempt in $(seq 1 180); do
      if docker exec "$CONTAINER" curl -sf --max-time 3 http://127.0.0.1:18580/health >/dev/null; then
        echo "Ready: $SERVED_MODEL_NAME; run.sh demo then run.sh stop $run_id"
        exit 0
      fi
      sleep 2
    done
    echo 'Readiness timeout; requesting cleanup of this run, inspect its log' >&2
    bash "$workdir/scripts/stop_server.sh" "$run_id" || true
    exit 1 ;;
  fixed-4k) export FIXED_CONCURRENCIES='1 2 4 8 16 32' ;;
  fixed-64k) export FIXED_INPUT_LEN=65536 FIXED_SMOKE_64K=1 FIXED_CONCURRENCIES='1 2 4' ;;
  peak-4k) export FIXED_CONCURRENCIES="$PEAK_4K_CONCURRENCY" FIXED_MEASURE_ROUNDS=3 ;;
  peak-64k) export FIXED_INPUT_LEN=65536 FIXED_SMOKE_64K=1 FIXED_CONCURRENCIES=2 FIXED_MEASURE_ROUNDS=3 ;;
  sharegpt)
    export SHAREGPT_CONCURRENCIES='1 4 16 32 64' SHAREGPT_ROUNDS=1
    exec bash "$workdir/scripts/run_sharegpt_round.sh" "$run_id" "$VARIANT" ;;
  accuracy) exec bash "$workdir/scripts/run_gsm8k_full_final.sh" "$run_id" "$PRECISION" ;;
  *) echo "Unknown action: $action" >&2; exit 2 ;;
esac
exec bash "$workdir/scripts/run_fixed_round.sh" "$run_id" "$VARIANT"
