#!/usr/bin/env bash
# Install missing task-local reproduction files, refusing to overwrite differences.
set -euo pipefail
package_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
workdir=/data/zk/qwen38
mkdir -p "$workdir/scripts" "$workdir/datasets"
for source in "$package_root"/scripts/engine/*; do
  target="$workdir/scripts/$(basename "$source")"
  if [[ -e "$target" ]]; then
    cmp -s "$source" "$target" || { echo "Different installed file: $target; choose explicitly before replacing" >&2; exit 2; }
  else
    cp "$source" "$target"
    [[ "$target" != *.sh ]] || chmod u+x "$target"
  fi
done
archive=opencompass-93a0bcb-source.tar
if [[ -e "$workdir/datasets/$archive" ]]; then
  cmp -s "$package_root/vendor/$archive" "$workdir/datasets/$archive" || exit 2
else
  cp "$package_root/vendor/$archive" "$workdir/datasets/$archive"
fi
echo 'Reproduction files ready; no service or benchmark has been started.'
