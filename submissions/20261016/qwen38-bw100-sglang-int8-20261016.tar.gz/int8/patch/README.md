本提交采用适配镜像已有能力与配置组合，无新增框架/Kernel 补丁。NN GEMM 试验补丁未启用，custom all-reduce 禁用。历史启动脚本按日志 SHA256 收录在 config/historical-run-server/；源码哈希不同不冒称同一快照。第三方组件许可证以原镜像和 vendor 源码内声明为准。
