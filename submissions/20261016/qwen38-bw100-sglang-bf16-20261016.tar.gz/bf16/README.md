# Qwen3.8-27B BW100 BF16 提交材料

本包包括代码/配置、五段式[性能报告](PERFORMANCE_REPORT.md)、原始日志、完整结果与 Demo 入口。采用现有全档单轮数据和关键边界三轮复测，按当前用户决定不再补跑。GSM8K 已完成，其他精度未测；轮数差异与提交限制见报告，未宣称已获官方准入认可。

## 环境准备

使用 env_declare.yaml 指定的适配镜像，禁止用通用 PyPI torch/sglang 替换 DTK 版本。宿主机需 Docker、DTK 驱动、hy-smi，模型与数据由评审自行准备；模型权重、672MB ShareGPT 文件及 GSM8K 数据不打入本包，来源与校验值见 config/data-manifests/。OpenCompass 固定源码归档与客户端依赖已附 vendor/ 和 scripts/engine/，客户端锁定信息见 config/eval-client-provenance/。

实验机已有容器 `zk-qwen38`，模型在容器内 `/data/zk/qwen38/model`。若创建等效容器，可参考如下实际环境约束（容器名冲突时先选择新名称并相应修改 config/runtime.env）：

```bash
docker run -dit --name zk-qwen38 --network host --ipc host --privileged \
  --device /dev/kfd --device /dev/dri --device /dev/mkfd \
  -v /dev/infiniband:/dev/infiniband -v /opt/hyhal:/opt/hyhal:ro \
  -v /data/zk/qwen38:/data/zk/qwen38 \
  -v /data1/model/Qwen3.8-27B:/data/zk/qwen38/model:ro \
  harbor.sourcefind.cn:5443/hcu/admin/base/sglang:0.5.12-ubuntu22.04-dtk2604-py3.10 bash
```

将本包放到宿主机 `/data/zk/qwen38/submissions/bf16/`。以下脚本均从**宿主机**执行：

```bash
cd /data/zk/qwen38/submissions/bf16
bash scripts/install.sh
# 仅复制缺失文件；已有同名文件若内容不同会停止，不覆盖现有代码。
DCU_DEVICES=2,3 bash scripts/run.sh start DEMO_BF16_NEW01
bash scripts/run.sh demo
bash scripts/run.sh stop DEMO_BF16_NEW01
```

启动前仅检查所选 DCU 的显存/HCU 占用；2、3 卡被占用时替换为空闲两卡，不停止他人任务。端口为 18580（HTTP）、19580（通信），同一宿主机两包按顺序运行。Demo 是推理示例，不作为跑分。演示视频未录制；可用上述真实终端命令自行录制。

## Benchmark 复现入口（本次整理不执行）

准备数据至 config/data-manifests/ 声明的路径并核对 SHA256。以下每次使用全新 run ID，前一任务退出、所选卡空闲后再启动下一任务：

```bash
DCU_DEVICES=2,3 bash scripts/run.sh fixed-4k R_BF16_4K_NEW01
DCU_DEVICES=2,3 bash scripts/run.sh fixed-64k R_BF16_64K_NEW01
DCU_DEVICES=2,3 bash scripts/run.sh peak-4k R_BF16_PEAK4K_NEW01
DCU_DEVICES=2,3 bash scripts/run.sh peak-64k R_BF16_PEAK64K_NEW01
DCU_DEVICES=2,3 bash scripts/run.sh sharegpt R_BF16_SG_NEW01
# 如需复现已有 GSM8K，先确保固定 CPU/API 客户端已准备：
docker exec zk-qwen38 bash /data/zk/qwen38/scripts/prepare_eval_client.sh
DCU_DEVICES=2,3 bash scripts/run.sh accuracy R_BF16_ACC_NEW01
```

已有 `/data/zk/qwen38/eval/client-20261012b` 时无需再创建；prepare 脚本拒绝覆盖。准确率推理在所选 DCU 上运行，CPU/API 客户端仅负责发请求和评分。禁止将其他未测试精度数据集写成已通过。

## 评审核查

- result/submission-summary.json：逐档数值、轮数、SLA、同档提升、原始请求哈希和 GSM8K 审计。
- logs/runs/：本精度所有引用的原始运行，包含启动参数、服务日志、请求、各轮汇总、结束时间；未完成/未过 SLA 的记录也保留。
- logs/provenance/：硬件/驱动声明、镜像 ID、冻结源码哈希与批次结束状态。
- config/historical-run-server/：日志中各个启动脚本 SHA 对应的源码原件。
- patch/README.md：没有新增推理源码补丁及排除项说明。
- FORUM_POST.md：可粘贴的提交帖，论坛 ID 待填写。

按用户提供主办方回复，使用带时间戳的命令行原文证据；本包未伪造截图或演示视频。未给定的精度成绩、视频、官方认可状态均不补写为完成。
